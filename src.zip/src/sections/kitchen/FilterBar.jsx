import React from "react";
import { Card, CardContent } from "@/components/ui/Card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/Select";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Slider } from "@/components/ui/Slider";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { Filter, Search, X } from "lucide-react";
import { ALL, toIDR, toSelectValue, fromSelectValue } from "@/lib/format";
import { LAYOUT_OPTIONS, STYLE_OPTIONS, FINISH_OPTIONS, TOP_OPTIONS } from "@/data/kitchenCatalogue";

export function FilterBar({ filters, setFilters, sort, setSort, priceRange, setPriceRange, resultCount, onReset, query, setQuery }) {
  return (
    <Card className="rounded-3xl shadow-sm">
      <CardContent className="p-4 md:p-5">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2"><Filter className="h-5 w-5"/><h3 className="font-medium">Filter Katalog</h3></div>
            <div className="text-sm text-muted-foreground">{resultCount} hasil</div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            <Select value={toSelectValue(filters.layout)} onValueChange={(v)=>setFilters((f)=>({...f, layout: fromSelectValue(v)}))}>
              <SelectTrigger className="rounded-2xl"><SelectValue placeholder="Layout" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>Semua layout</SelectItem>
                {LAYOUT_OPTIONS.map((l)=>(<SelectItem key={l} value={l}>{l}</SelectItem>))}
              </SelectContent>
            </Select>

            <Select value={toSelectValue(filters.style)} onValueChange={(v)=>setFilters((f)=>({...f, style: fromSelectValue(v)}))}>
              <SelectTrigger className="rounded-2xl"><SelectValue placeholder="Gaya" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>Semua gaya</SelectItem>
                {STYLE_OPTIONS.map((s)=>(<SelectItem key={s} value={s}>{s}</SelectItem>))}
              </SelectContent>
            </Select>

            <Select value={toSelectValue(filters.finish)} onValueChange={(v)=>setFilters((f)=>({...f, finish: fromSelectValue(v)}))}>
              <SelectTrigger className="rounded-2xl"><SelectValue placeholder="Finishing pintu" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>Semua finishing</SelectItem>
                {FINISH_OPTIONS.map((s)=>(<SelectItem key={s} value={s}>{s}</SelectItem>))}
              </SelectContent>
            </Select>

            <Select value={toSelectValue(filters.top)} onValueChange={(v)=>setFilters((f)=>({...f, top: fromSelectValue(v)}))}>
              <SelectTrigger className="rounded-2xl"><SelectValue placeholder="Top table" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL}>Semua top</SelectItem>
                {TOP_OPTIONS.map((s)=>(<SelectItem key={s} value={s}>{s}</SelectItem>))}
              </SelectContent>
            </Select>

            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="rounded-2xl"><SelectValue placeholder="Urutkan"/></SelectTrigger>
              <SelectContent>{["Disarankan","Terbaru","Harga Rendah→Tinggi","Harga Tinggi→Rendah","Lead time tercepat","A–Z"].map((s)=>(<SelectItem key={s} value={s}>{s}</SelectItem>))}</SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Search className="h-4 w-4"/>
              <Input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Cari nama/gaya/fitur…" className="rounded-2xl"/>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-center">
            <div className="flex items-center gap-3">
              <Label className="whitespace-nowrap">Range harga (Rp/m’)</Label>
              <Slider value={priceRange} onValueChange={setPriceRange} min={2500000} max={7000000} step={50000} className="w-full"/>
              <div className="text-sm tabular-nums text-muted-foreground w-44 text-right">{toIDR(priceRange[0])} – {toIDR(priceRange[1])}</div>
            </div>
            <div className="flex items-center justify-end gap-2">
              <Button variant="ghost" className="rounded-2xl" onClick={onReset}><X className="h-4 w-4 mr-1"/>Hapus filter</Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function AppliedChips({ filters, priceRange, onClearAll }) {
  const chips = [];
  if (filters.layout) chips.push({ k: "Layout", v: filters.layout });
  if (filters.style) chips.push({ k: "Gaya", v: filters.style });
  if (filters.finish) chips.push({ k: "Finishing", v: filters.finish });
  if (filters.top) chips.push({ k: "Top", v: filters.top });
  if (priceRange) chips.push({ k: "Harga", v: `${toIDR(priceRange[0])}–${toIDR(priceRange[1])}/m’` });
  if (chips.length === 0) return null;
  return (
    <div className="flex flex-wrap items-center gap-2">
      {chips.map((c, i) => (<Badge key={i} variant="secondary" className="rounded-xl">{c.k}: {c.v}</Badge>))}
      <Button size="sm" variant="ghost" className="rounded-2xl" onClick={onClearAll}><X className="h-4 w-4 mr-1"/>Reset</Button>
    </div>
  );
}
