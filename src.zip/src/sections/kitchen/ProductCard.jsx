import React from "react";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Heart, LayoutDashboard, Ruler, Timer, Star } from "lucide-react";
import { toIDR } from "@/lib/format";

/**
 * EXPECTED item shape (yang sekarang sudah ada di katalog BIG):
 * - name, image/img/cover/thumbnail
 * - layout (e.g. "L", "U", "Single")
 * - style: string[]
 * - lead_time_weeks: number
 * - price_per_m: [min, max]
 * - badges?: string[]
 * - worktop: { material: string, thickness_mm: number }
 * - rating?: number             (optional)
 * - price_original_per_m?: number (optional: untuk harga coret) 
 */

function SpecPill({ icon: Icon, children }) {
  return (
    <div className="flex items-center gap-1.5 rounded-lg bg-zinc-50 px-2.5 py-1.5 text-xs text-zinc-700">
      <Icon className="h-4 w-4" />
      <span className="font-medium">{children}</span>
    </div>
  );
}

export default function ProductCard({ item, onToggleWishlist, isWishlisted }) {
  const imgSrc =
    item.image ||
    item.img ||
    item.cover ||
    item.thumbnail ||
    "/catalogue/placeholder.jpg";

  const title = item.name || item.title || item.slug || "Catalogue";
  const subtitle = `Layout ${item.layout} • ${item.style?.join(", ") || "—"}`;
  const lead = item.lead_time_weeks ? `${item.lead_time_weeks} minggu` : "—";
  const areaLabel =
    item.worktop?.material && item.worktop?.thickness_mm
      ? `${item.worktop.material} ${item.worktop.thickness_mm} mm`
      : item.worktop?.material || "Top —";

  const priceFrom = toIDR(item.price_per_m?.[0] ?? 0);
  const priceTo = toIDR(item.price_per_m?.[1] ?? 0);
  const priceRange = `${priceFrom} – ${priceTo} / m’`;

  const priceStrike =
    typeof item.price_original_per_m === "number"
      ? toIDR(item.price_original_per_m)
      : null;

  const badgeText =
    (Array.isArray(item.badges) && item.badges.length > 0 && item.badges[0]) ||
    null;

  const rating =
    typeof item.rating === "number"
      ? Number(item.rating).toFixed(2)
      : undefined;

  return (
    <Card className="group overflow-hidden rounded-2xl border border-zinc-200 shadow-sm transition hover:shadow-lg">
      {/* IMAGE HEADER */}
      <CardHeader className="p-0">
        <div className="relative">
          <img
            src={imgSrc}
            alt={title}
            className="block w-full aspect-[16/10] object-cover"
            loading="lazy"
          />

          {/* Discount / Promo chip */}
          {badgeText && (
            <div className="absolute left-3 top-3">
              <Badge className="rounded-full bg-emerald-100 text-emerald-700 shadow-sm px-2.5 py-1 text-xs font-semibold">
                {badgeText}
              </Badge>
            </div>
          )}

          {/* Wishlist */}
          <button
            type="button"
            aria-label={isWishlisted ? "Hapus dari favorit" : "Tambah ke favorit"}
            onClick={(e) => {
              e.stopPropagation?.();
              onToggleWishlist?.();
            }}
            className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 backdrop-blur shadow-sm transition hover:scale-105"
          >
            <Heart
              className={`h-5 w-5 ${
                isWishlisted ? "fill-red-500 text-red-500" : "text-zinc-700"
              }`}
            />
          </button>

          {/* Dots indicator (dekoratif) */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className={`h-1.5 w-1.5 rounded-full ${
                  i === 1 ? "bg-white" : "bg-white/60"
                }`}
              />
            ))}
          </div>
        </div>
      </CardHeader>

      {/* BODY */}
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base leading-snug line-clamp-1">
              {title}
            </CardTitle>
            <CardDescription className="mt-0.5 text-sm line-clamp-1">
              {subtitle}
            </CardDescription>
          </div>

          {/* Price & Rating */}
          <div className="text-right">
            {priceStrike && (
              <div className="text-xs text-zinc-400 line-through tabular-nums">
                {priceStrike}
              </div>
            )}
            <div className="text-lg font-bold text-emerald-700 tabular-nums">
              {priceFrom}
            </div>
            <div className="text-[11px] text-zinc-500">per meter lari</div>
          </div>
        </div>

        {/* SPECS ROW ala property card */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <SpecPill icon={LayoutDashboard}>Layout {item.layout}</SpecPill>
          <SpecPill icon={Ruler}>{areaLabel}</SpecPill>
          <SpecPill icon={Timer}>Lead {lead}</SpecPill>
        </div>
      </CardContent>

      {/* FOOTER */}
      <CardFooter className="p-4 pt-0 flex items-end justify-between">
        <div className="text-xs text-zinc-500">{priceRange}</div>

        <div className="flex items-center gap-2">
          {rating && (
            <div className="hidden sm:flex items-center gap-1 text-sm text-zinc-700">
              <Star className="h-4 w-4 text-emerald-500 fill-emerald-500" />
              <span className="font-medium">{rating}</span>
            </div>
          )}
          <div className="hidden sm:block">
            <Button variant="secondary" className="rounded-xl">
              Estimasi
            </Button>
          </div>
          <Button className="rounded-xl">Lihat detail</Button>
        </div>
      </CardFooter>
    </Card>
  );
}
